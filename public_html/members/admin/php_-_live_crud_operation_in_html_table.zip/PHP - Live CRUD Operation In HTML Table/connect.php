<?php
	$conn = new mysqli('localhost', 'root', '', 'phptut');
	if(!$conn){
		die("Fatal Error: Connection Error!");
	}
?>