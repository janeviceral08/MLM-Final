<?php
	require 'connect.php';
	$result = '';
	$query = $conn->query("SELECT * FROM `member`");
	
	$result .= '
		<table class = "table table-bordered">
			<thead>
				<tr>
					<th>Firstname</th>
					<th>Lastname</th>
					<th>Address</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
	';
	if($query->num_rows > 0){
		while($fetch = $query->fetch_array()){
			$result .='
			
				<tr>
					<td class = "firstname" data-firstname = '.$fetch['mem_id'].' contenteditable >'.$fetch['firstname'].'</td>
					<td class = "lastname" data-lastname = '.$fetch['mem_id'].' contenteditable>'.$fetch['lastname'].'</td>
					<td class = "address" data-address = '.$fetch['mem_id'].' contenteditable>'.$fetch['address'].'</td>
					<td><center><button class = "btn btn-danger btn_delete" name = "'.$fetch['mem_id'].'"><span class = "glyphicon glyphicon-remove"></span></button></center></td>
				</tr>
				
			';
			
		}
		
		$result .='
				<tr>
					<td id = "firstname" contenteditable></td>
					<td id = "lastname" contenteditable></td>
					<td id = "address" contenteditable></td>
					<td><center><button class = "btn btn-success" id = "btn_add"><span class = "glyphicon glyphicon-plus"></span></button></center></td>
				</tr>
			
			';
			
	}else{
		$result .='
			<tr>
				<td id = "firstname" contenteditable></td>
					<td id = "lastname" contenteditable></td>
					<td id = "address" contenteditable></td>
				<td><center><button class = "btn btn-success" id = "btn_add"><span class = "glyphicon glyphicon-plus"></span></button></center></td>
			</tr>
		';
	}
	
	$result .= '
			</tbody>
		</table>
	';
	
	echo $result;
	
?>